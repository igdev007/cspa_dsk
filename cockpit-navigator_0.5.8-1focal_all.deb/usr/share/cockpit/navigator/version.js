export let NAVIGATOR_VERSION = " 0.5.8-1focal";
